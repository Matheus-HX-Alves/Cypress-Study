const el = require('./elements').ELEMENTS;

class Register {
    accessRegistrationPage() {
        cy.visit('http://localhost:4200');
        cy.get(el.registerNow).click();
    }

    fillFormManually() {
        cy.get(el.email).type('Test@test.com');
        cy.get(el.fullName).type('Test Name Xpto');
        cy.get(el.registerUserName).type('nickname' + (Math.floor(Math.random() * 900) + 100));
        cy.get(el.registerPassword).type('123123123');
    }

    submitRegister() {
        cy.get(el.btnRegister).click();
    }
}

export default new Register();
