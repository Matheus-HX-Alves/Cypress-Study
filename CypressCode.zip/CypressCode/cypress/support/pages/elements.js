export const ELEMENTS = {
    registerNow: '[data-test="register"]',
    email: '[data-test="email"]',
    fullName: '[data-test="fullName"]',
    registerUserName: '[data-test="registerUserName"]',
    registerPassword: '[data-test="registerPassword"]',
    btnRegister: '[data-test="btnRegister"]'
}