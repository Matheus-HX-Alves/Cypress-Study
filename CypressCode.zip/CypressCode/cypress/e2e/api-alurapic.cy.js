describe('Alurapic API', () => {
    it('API Data Validation', () => {
        cy.request({
            method: 'POST',
            url: 'http://localhost:3000/user/login',
            body: Cypress.env()
        }).then((res) => {
            expect(res.status).to.be.equal(200);
            expect(res.body).is.not.empty;
            expect(res.body).to.have.property('id');
            expect(res.body.id).to.be.equal(4);
        });
    });

    it('API Photos Consulting', () => {
        const expectedTime = 2000;
        cy.request({
            method: 'GET',
            url: 'http://localhost:3000/math22/photos',
            body: Cypress.env()
        }).then((res) => {
            expect(res.status).to.be.equal(200);
            expect(res.body).is.not.empty;
            expect(res.body[0]).to.have.property('id');
            expect(res.body[0].id).to.be.equal(5);
            expect(res.duration).to.be.lte(expectedTime);
        });
    });
});
