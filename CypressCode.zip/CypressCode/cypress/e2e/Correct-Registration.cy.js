import Register from "../support/pages/registrationPage";

describe('New user registration page', () => {
    beforeEach(() => {
        cy.visit('http://localhost:4200');
    });

    it('Fill in user fields correctly for registration.', () => {
        Register.accessRegistrationPage();
        Register.fillFormManually();
        Register.submitRegister();
    });

    // const users = require('../fixtures/users.json')
    // users.forEach(user => {
    //     it('Fill in user fields correctly for registration.', () => {
    //         cy.contains('a','Register now').click();
    //         cy.get('[data-test="email"]').type('test'+ (Math.floor(Math.random() * 900) + 100) + user.email);
    //         cy.get('[data-test="fullName"]').type(user.fullName);
    //         cy.get('[data-test="registerUserName"]').type(user.userName + (Math.floor(Math.random() * 900) + 100));
    //         cy.get('[data-test="registerPassword"]').type(user.password + (Math.floor(Math.random() * 900) + 100));
    //         cy.contains('button','Register').click();
    //     });
    // });
});
