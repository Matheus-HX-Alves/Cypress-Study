
describe('User login page', () => {

    beforeEach(() => {
        cy.visit('http://localhost:4200');
        cy.intercept('POST', 'http://localhost:3000/user/login', {statusCode:400}).as('stubPost');
    });

    it('Fill in user fields incorrectly for registration.', () => {
        cy.contains('User name is required!').should('be.visible');
        cy.contains('Password is required!').should('be.visible');
    });

    it('Must fail for the fields been visible.', () => {
        cy.login('wrong', 'wrong');
        cy.wait('@stubPost');
    });

});
