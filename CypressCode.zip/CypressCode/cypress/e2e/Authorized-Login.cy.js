describe('User login page', () => {
    beforeEach(() => {cy.visit('http://localhost:4200')});

    it('Fill in user fields correctly for registration.', () => {
        cy.login('nickname1','123!123!')
    })
})